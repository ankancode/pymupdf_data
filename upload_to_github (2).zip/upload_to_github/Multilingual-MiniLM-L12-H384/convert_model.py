#!/usr/bin/env python3
import logging
from transformers import BertModel, BertTokenizer, TFBertModel, XLMRobertaTokenizer

logging.basicConfig(level=logging.INFO, filename="log.txt")
model = BertModel.from_pretrained("../../Multilingual-MiniLM-L12-H384/")
tf_model = TFBertModel.from_pretrained("../../Multilingual-MiniLM-L12-H384/", from_pt=True)
model.save_pretrained("./")
tf_model.save_pretrained("./")

tok = XLMRobertaTokenizer.from_pretrained("../../Multilingual-MiniLM-L12-H384/sentencepiece.bpe.model")
tok.save_pretrained("./")
